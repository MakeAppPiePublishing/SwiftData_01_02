//
//  HuliPizzaPersistentApp.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 10/27/23.
//

import SwiftUI

@main
struct HuliPizzaPersistentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
